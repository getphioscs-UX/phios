import {mountProgressiveExplorer} from './progressive-explorer.js';
import {enhanceExplorerShell} from './explorer-shell.js';
const esc=v=>String(v??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
export function renderExpansionExplorer(host,{objects,chains,bridge,locale='en',locationRef=window.location,historyRef=window.history,eventTarget=window}){
 const zh=locale==='zh-Hans',tr=(en,cn)=>zh?cn:en;
 const article=o=>o.articles.find(a=>a.locale===locale)||o.articles.find(a=>a.locale==='en');
 const title=o=>zh?o.title:article(o).title;
 host.innerHTML=`<h2>${tr('Expansion and scale transition','扩展与尺度转换')}</h2><p>${tr('Explore published explanations of expansion, constraints and new loads. The sequence guides reading; it does not predict an inevitable outcome.','探索扩展、约束与新增负荷的已发布解释。下方顺序用于阅读，不预测必然结果。')}</p><label>${tr('Search topics','搜索主题')} <input type="search"></label><div class="expansion-layout"><nav data-expansion-list aria-label="${tr('Expansion topics','扩展主题')}"></nav><article data-expansion-inspector></article></div><h3>${tr('Follow the reading sequence','沿阅读顺序探索')}</h3><ol class="expansion-chain">${chains.chains[0].stageIds.map(id=>{const o=objects.find(o=>o.objectId===id);return `<li><button type="button" data-expansion-object="${esc(id)}">${esc(title(o))}</button></li>`;}).join('')}</ol><a href="${esc(bridge.targetRoute)}">${tr('Continue to Civilization Atlas','继续前往文明图谱')}</a>`;
 const list=host.querySelector('[data-expansion-list]'),inspector=host.querySelector('[data-expansion-inspector]'),input=host.querySelector('input');let selected;
 function renderList(){const term=input.value.trim().toLowerCase();list.innerHTML=objects.filter(o=>`${o.title} ${article(o).title} ${article(o).summary}`.toLowerCase().includes(term)).map(o=>`<button type="button" data-expansion-object="${esc(o.objectId)}" aria-pressed="${o.objectId===selected}">${esc(title(o))}</button>`).join('')||`<p role="status">${tr('No matching topics','没有符合的主题')}</p>`;}
 function select(id,push=false){const o=objects.find(o=>o.objectId===id);selected=o?.objectId;inspector.innerHTML=o?`<h3>${esc(title(o))}</h3><p>${esc(article(o).summary)}</p><p class="expansion-note">${tr('Published article summary; the article may cover several canonical topics.','已发布文章摘要；同一篇文章可能覆盖多个规范主题。')}</p><h4>${tr('Capacity, constraints and new loads','容量、约束与新增负荷')}</h4><p>${tr('Read the source for the conditions of this topic. No numerical threshold or automatic scale classification is provided.','请阅读来源中针对该主题的条件。这里不提供数值阈值或自动尺度判定。')}</p><a href="${esc(article(o).href)}">${tr('Read the published explanation','阅读已发布解释')}</a><details><summary>${tr('Source and review boundary','来源与审核边界')}</summary><p>${esc(o.nodeCode)} · ${tr('Pages','页')} ${o.sourceSection.pages.join('–')}</p><p>${tr('The new classification and links await consolidated review.','新增分类与关系留待集中审核。')}</p></details>`:`<p>${tr('Topic unavailable. Select another topic.','主题不可用，请选择其他主题。')}</p>`;if(push){const url=new URL(locationRef.href);url.searchParams.set('expansion',id);url.hash='expansion';historyRef.pushState(null,'',url);}renderList();}
 const sync=()=>select(new URL(locationRef.href).searchParams.get('expansion')||new URL(locationRef.href).searchParams.get('scale')||objects[0]?.objectId);
 const click=e=>{const b=e.target.closest('[data-expansion-object]');if(b&&host.contains(b)){select(b.dataset.expansionObject,true);host.querySelector(`[data-expansion-object="${b.dataset.expansionObject}"]`)?.focus();}};
 host.addEventListener('click',click);input.addEventListener('input',renderList);eventTarget.addEventListener('popstate',sync);sync();
 const disposeShell=enhanceExplorerShell(host,{layout:'.expansion-layout',nav:'[data-expansion-list]',inspector:'[data-expansion-inspector]',locale});
 return ()=>{disposeShell();host.removeEventListener('click',click);input.removeEventListener('input',renderList);eventTarget.removeEventListener('popstate',sync);};
}
async function mountFullReadingView(host,locale){
 try{const load=async path=>{const r=await fetch(path);if(!r.ok)throw new Error('unavailable');return r.json();};const [registry,chains,bridge]=await Promise.all(['book-4/book-4-expansion-mode-registry-v1.json','book-4/book-4-expansion-chain-registry-v1.json','bridges/book-4-to-book-5-civilization-threshold-v1.json'].map(p=>load('/content/knowledge/structured/'+p)));if(!host.isConnected)return ()=>{};return renderExpansionExplorer(host,{objects:registry.objects,chains,bridge,locale});}
 catch{host.textContent=locale==='zh-Hans'?'扩展探索暂不可用，请使用章节入口。':'Expansion explorer unavailable. Use the chapter links.';return ()=>{};}
}

export async function mountExpansionExplorer(host,locale){
 try{return await mountProgressiveExplorer(host,'BOOK-4',locale,()=>mountFullReadingView(host,locale));}catch{host.textContent=locale==='zh-Hans'?'主题暂不可用，请阅读书籍章节。':'Topics unavailable. Use the book chapter links.';return ()=>{};}
}

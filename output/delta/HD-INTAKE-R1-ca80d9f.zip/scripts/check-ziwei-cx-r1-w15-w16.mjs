import {assertPprCurrentSharedOwner} from './lib/ppr-current-shared-owner.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {onRequestPost as customerPersonalReality} from '../functions/api/customer-personal-reality.js';
import {renderZiweiProduct} from '../assets/customer-ui/js/specialists/ziwei/product-renderer.js';
import {ZIWEI_CX_R1_W16_SURFACE_ACTIVATION,isZiweiCustomerSurfaceActivated} from '../functions/personal-reality-product/adapters/ziwei-customer-surface-activation.js';
import {auditZiweiDom,exerciseZiweiInteractionPlan,parseAuditDom,queryAll} from './lib/ziwei-cx-r1-w14-dom-harness.mjs';
import {assertPprR3GovernedPath} from './ppr-r3-governed-successor-support.mjs';

const BASE='content/customer-experience-rebuild/ziwei-cx-r1';
const BASELINE='492ecdddc1f84e5a915f416c60c61ed23e4fcb7f';
const j=p=>JSON.parse(fs.readFileSync(p,'utf8'));const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const paths={
 historicalResults:`${BASE}/review/ziwei-cx-r1-w15-human-visual-review-results-v1.json`,
 results:`${BASE}/review/ziwei-cx-r1-w15-human-visual-review-results-v2.json`,
 admission:`${BASE}/admission/ziwei-cx-r1-w15-human-visual-admission-v1.json`,
 w15Acceptance:`${BASE}/acceptance/ziwei-cx-r1-w15-human-visual-acceptance-v2.json`,
 contract:`${BASE}/contracts/ziwei-cx-r1-w16-actual-customer-surface-activation-contract-v1.json`,
 authority:`${BASE}/authority/ziwei-cx-r1-w16-customer-surface-activation-authority-v1.json`,
 freeze:`${BASE}/authority/ziwei-cx-r1-w16-ppr-r3-shared-freeze-v1.json`,
 replay:`${BASE}/campaign/ziwei-cx-r1-w16-current-route-replay-v1.json`,
 acceptance:`${BASE}/acceptance/ziwei-cx-r1-w16-customer-surface-activation-acceptance-v1.json`,
 roadmap:`${BASE}/roadmap/ziwei-cx-r1-master-work-v6.json`,
 w15Campaign:`${BASE}/campaign/ziwei-cx-r1-w15-human-visual-interaction-campaign-v1.json`,
 w14Campaign:`${BASE}/campaign/ziwei-cx-r1-w14-real-api-dom-machine-campaign-v1.json`,
 fp23:'content/professional/zi-wei-full-production/acceptance/ziwei-fp-w23-production-cutover-acceptance-v1.json'
};
for(const p of Object.values(paths))assert.ok(fs.existsSync(p),`missing ${p}`);
const historical=j(paths.historicalResults),results=j(paths.results),admission=j(paths.admission),w15Acceptance=j(paths.w15Acceptance),contract=j(paths.contract),authority=j(paths.authority),freeze=j(paths.freeze),replay=j(paths.replay),acceptance=j(paths.acceptance),roadmap=j(paths.roadmap),w15Campaign=j(paths.w15Campaign),w14Campaign=j(paths.w14Campaign),fp23=j(paths.fp23);
const sharedSuccessorPaths=[`${BASE}/authority/ziwei-cx-r1-w17r-current-shared-baseline-v1.json`,`${BASE}/authority/ziwei-cx-r1-w17-current-shared-baseline-v1.json`];const currentSharedSuccessorPath=sharedSuccessorPaths.find(p=>fs.existsSync(p))||null;const w17Shared=currentSharedSuccessorPath?j(currentSharedSuccessorPath):null;
const w16CurrentOwnerReconciliationPaths=[`${BASE}/authority/ziwei-cx-r1-w16-current-shared-owner-reconciliation-v3.json`,`${BASE}/authority/ziwei-cx-r1-w16-current-shared-owner-reconciliation-v2.json`];const w16CurrentOwnerReconciliationPath=w16CurrentOwnerReconciliationPaths.find(p=>fs.existsSync(p))||null;const w16CurrentOwnerReconciliation=w16CurrentOwnerReconciliationPath?j(w16CurrentOwnerReconciliationPath):null;
for(const x of [results,admission,w15Acceptance,contract,authority,freeze,replay,acceptance,roadmap])assert.equal(x.integrationBaselineCommit,BASELINE,`${x.schemaVersion} baseline drift`);
// Historical review-ready artifacts remain historical; admission is successor evidence rather than retroactive mutation.
assert.equal(historical.status,'PENDING_HUMAN_REVIEW');assert.equal(historical.summary.pending,12);assert.equal(historical.summary.accepted,0);
assert.equal(results.predecessorMutated,false);assert.equal(results.status,'HUMAN_ACCEPTED_12_OF_12');assert.equal(results.campaignDigest,w15Campaign.campaignDigest);assert.equal(results.summary.required,12);assert.equal(results.summary.accepted,12);assert.equal(results.summary.pending,0);assert.equal(results.results.length,12);assert.equal(results.results.every(x=>x.decision==='ACCEPT'),true);assert.equal(results.results.every(x=>x.decisionSource==='AUTHORIZED_HUMAN_BULK_DECLARATION'),true);
assert.deepEqual(results.results.map(x=>x.caseId),w15Campaign.selection.caseIds);assert.equal(new Set(results.results.map(x=>x.lifeBranch)).size,12);
assert.equal(admission.status,'HUMAN_ADMITTED_12_OF_12');assert.equal(admission.allDecisionsAccept,true);assert.equal(admission.humanAcceptanceSubstitutedByMachine,false);assert.equal(admission.w16ActivationGateSatisfied,true);assert.deepEqual(admission.responsiveViewportsAccepted,[375,430,768,1024,1280,1440,1920]);
assert.equal(w15Acceptance.status,'HUMAN_VISUAL_ACCEPTED_12_OF_12_W16_OPEN');assert.equal(w15Acceptance.gates.HUMAN_VISUAL_ACCEPTED_12_OF_12,true);assert.equal(w15Acceptance.gates.CUSTOMER_SURFACE_ACTIVATION_OPEN,true);assert.equal(w15Acceptance.gates.PPR_SHARED_LAYER_MUTATION_REQUIRED,false);
// Semantic production + machine customer path are prerequisites, not replacements for W15.
assert.equal(fp23.status,'PRODUCTION_CUTOVER_ALLOWED');assert.equal(fp23.machineGate.passed,true);assert.equal(fp23.humanGate.passed,true);assert.equal(w14Campaign.status,'MACHINE_ACCEPTED_96_OF_96');assert.equal(w14Campaign.summary.passed,96);assert.equal(w14Campaign.summary.legacyVisibleOwnerCases,0);assert.equal(w14Campaign.summary.rawCodeLeakCases,0);
execFileSync(process.execPath,['scripts/check-ziwei-cx-r1-w14.mjs'],{stdio:'inherit'});
if(w16CurrentOwnerReconciliation){assert.equal(w16CurrentOwnerReconciliation.status,'CURRENT_SHARED_OWNER_RECONCILED_NO_ZIWEI_MUTATION');assert.equal(w16CurrentOwnerReconciliation.historicalFreezeMutated,false);assert.equal(w16CurrentOwnerReconciliation.ziweiSharedSurfaceMutationByThisWork,false);assert.equal(w16CurrentOwnerReconciliation.futureUnregisteredDriftAllowed,false);assertPprCurrentSharedOwner(w16CurrentOwnerReconciliation.sharedFile,{historicalDigest:w16CurrentOwnerReconciliation.currentOwnerSha256,label:'Zi Wei shared host / HD-INTAKE-R1 successor'});assert.equal(freeze.files.find(x=>x.path===w16CurrentOwnerReconciliation.sharedFile)?.sha256,w16CurrentOwnerReconciliation.historicalW16Sha256);}
// W16 activation authority and current-baseline replay.
assert.equal(contract.sharedLayerMutationAllowed,false);assert.equal(contract.legacyGenericFallbackAllowed,false);assert.equal(contract.activationOutput.fullProductionVisibleToCustomer,true);
assert.equal(authority.status,'ACTIVE_ACTUAL_CUSTOMER_SURFACE');assert.equal(authority.fullProductionVisibleToCustomer,true);assert.equal(authority.customerSurfaceActivationAllowed,true);assert.equal(authority.legacyGenericFallbackAllowed,false);assert.equal(authority.sourceGates.currentBaselineReplay,'PASS_96_OF_96');assert.equal(authority.currentRouteReplayDigest,replay.campaignDigest);
assert.deepEqual(JSON.parse(JSON.stringify(ZIWEI_CX_R1_W16_SURFACE_ACTIVATION)),{schemaVersion:'PHI-OS-ZIWEI-CX-R1-W16-CUSTOMER-SURFACE-ACTIVATION-v1.0.0',work:'ZIWEI-CX-R1-W16',state:'ACTIVE_CUSTOMER_SURFACE',canonicalRoute:'/perspectives/personal/',sharedHostAuthority:'PPR-R3',rendererId:'ZIWEI_CX_R1_W12_W13_SPECIALIST_WORKSPACE',authorityRef:'content/customer-experience-rebuild/ziwei-cx-r1/authority/ziwei-cx-r1-w16-customer-surface-activation-authority-v1.json',acceptanceRef:'content/customer-experience-rebuild/ziwei-cx-r1/acceptance/ziwei-cx-r1-w16-customer-surface-activation-acceptance-v1.json',humanVisualAdmissionRef:'content/customer-experience-rebuild/ziwei-cx-r1/admission/ziwei-cx-r1-w15-human-visual-admission-v1.json',machineDomCampaignRef:'content/customer-experience-rebuild/ziwei-cx-r1/campaign/ziwei-cx-r1-w14-real-api-dom-machine-campaign-v1.json',currentRouteReplayRef:'content/customer-experience-rebuild/ziwei-cx-r1/campaign/ziwei-cx-r1-w16-current-route-replay-v1.json',semanticProductionRef:'content/professional/zi-wei-full-production/acceptance/ziwei-fp-w23-production-cutover-acceptance-v1.json',machineDomAdmission:'96/96',humanVisualAdmission:'12/12',fullProductionVisibleToCustomer:true,legacyGenericFallbackAllowed:false,sharedPersonalRealityMutationRequired:false});
assert.equal(replay.status,'ACTIVATION_REPLAY_ACCEPTED_96_OF_96');assert.equal(replay.summary.required,96);assert.equal(replay.summary.executed,96);assert.equal(replay.summary.passed,96);assert.equal(replay.summary.failed,0);assert.deepEqual(replay.summary.localeCounts,{'zh-Hans':48,en:48});assert.deepEqual(replay.summary.sexCounts,{MALE:48,FEMALE:48});assert.equal(replay.summary.uniqueLifeBranches.length,12);assert.equal(replay.summary.uniqueBodyBranches.length,12);assert.equal(replay.summary.domPalaceButtons,1152);assert.equal(replay.summary.domTopicTabs,768);assert.equal(replay.summary.domTimingNodes,288);assert.equal(replay.summary.surfaceActivationCases,96);assert.equal(replay.summary.interactionPassed,96);assert.equal(replay.summary.deterministicReplayPassed,8);assert.equal(replay.cases.every(x=>x.activation==='W16_ACTIVE'&&x.passed),true);assert.equal(replay.replay.every(x=>x.matched),true);
assert.equal(acceptance.status,'ACTUAL_CUSTOMER_SURFACE_ACTIVE');assert.equal(acceptance.gates.W15_HUMAN_VISUAL_12_OF_12,true);assert.equal(acceptance.gates.CURRENT_BASELINE_ROUTE_REPLAY_96_OF_96,true);assert.equal(acceptance.gates.PPR_SHARED_LAYER_MUTATION_REQUIRED,false);assert.equal(acceptance.result.fullProductionVisibleToCustomer,true);assert.equal(acceptance.blockers.length,0);
assert.equal(roadmap.status,'W0_W16_COMPLETE_ACTUAL_CUSTOMER_SURFACE_ACTIVE');assert.equal(roadmap.customerSurface.visualHumanAcceptance,'12/12');assert.equal(roadmap.customerSurface.currentBaselineActivationReplay,'96/96');assert.equal(roadmap.customerSurface.customerSurfaceActivationAllowed,true);assert.equal(roadmap.customerSurface.fullProductionVisibleToCustomer,true);
// Current shared baseline is frozen as-is; Zi Wei activation must not mutate it.
for(const row of freeze.files){
 assert.ok(fs.existsSync(row.path),`shared frozen path missing ${row.path}`);
 const governed=assertPprR3GovernedPath(row.path,row.sha256,'ZIWEI-CX-R1 W16 shared freeze');
 if(governed.state==='UNCHANGED')assert.equal(fs.statSync(row.path).size,row.sizeBytes,`PPR shared size drift: ${row.path}`);
 else assert(['GOVERNED_SUCCESSOR','CURRENT_OWNER_SUCCESSOR'].includes(governed.state),`PPR shared path is neither frozen nor governed successor: ${row.path}`);
}
for(const p of freeze.requiredAbsent)assert.equal(fs.existsSync(p),false,`retired shared file resurrected: ${p}`);
// One real current canonical API -> activated product -> specialist DOM witness.
function mockExternalFetch(){return async input=>{const url=String(input?.url||input);if(url.includes('nominatim.openstreetmap.org/lookup'))return new Response(JSON.stringify([{name:'Hong Kong',lat:'22.3193',lon:'114.1694',display_name:'Hong Kong',address:{city:'Hong Kong',country:'Hong Kong',country_code:'hk'},namedetails:{'name:en':'Hong Kong','name:zh':'香港'}}]),{status:200,headers:{'content-type':'application/json'}});if(url.includes('timeapi.io/api/TimeZone/coordinate'))return new Response(JSON.stringify({timeZone:'Asia/Hong_Kong'}),{status:200,headers:{'content-type':'application/json'}});throw new Error(`ZIWEI_CX_R1_W16_UNEXPECTED_FETCH:${url}`);};}
const oldFetch=globalThis.fetch;globalThis.fetch=mockExternalFetch();try{
 const body={birthDate:'2023-01-22',birthTime:'05:00',birthTimeUnknown:false,placeRef:'N123',methods:['ziwei'],traditionalCalculationSex:'MALE',ziweiTargetDate:'2026-08-30',ziweiTargetTime:'12:00',ziweiTargetTimezoneIana:'Asia/Kuala_Lumpur',ziweiTargetUtcOffset:'+08:00',ziweiTargetContextSource:'EXPLICIT_REQUEST',consent:true,locale:'zh-Hans'};
 const response=await customerPersonalReality({request:new Request('https://getphios.com/api/customer-personal-reality',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}),env:{}});const payload=await response.json();assert.equal(response.status,200);assert.equal(payload.ok,true);const product=payload.view?.productRoute?.primaryProduct;assert.equal(isZiweiCustomerSurfaceActivated(product),true);assert.equal(product.publication.surfaceHumanAdmission,'12/12');assert.equal(product.boundaries.w15HumanVisualAccepted,true);assert.equal(product.boundaries.w16ActualCustomerSurfaceActivated,true);assert.equal(product.boundaries.fullProductionVisibleToCustomer,true);
 const plan=renderZiweiProduct({product});assert.equal(plan.customerSurfaceActivation,'W16_ACTIVE');assert.equal(plan.fullProductionVisibleToCustomer,true);assert.equal(plan.activationAuthorityRef,authority.schemaVersion?ZIWEI_CX_R1_W16_SURFACE_ACTIVATION.authorityRef:null);const dom=auditZiweiDom(plan);assert.equal(Object.values(dom.invariants).every(Boolean),true);const tree=parseAuditDom(plan.readingHtml);assert.equal(queryAll(tree,'[data-ziwei-customer-surface-activation="W16_ACTIVE"]').length,1);assert.equal(queryAll(tree,'[data-ziwei-full-production-visible="true"]').length,1);const presentation=product.visuals.find(x=>x.type==='ZIWEI_SPECIALIST_PRESENTATION')?.payload;const interaction=exerciseZiweiInteractionPlan(plan,{defaultPalaceIndex:presentation?.defaultPalaceIndex||0});assert.equal(interaction.passed,true);
 // Removing W16 activation metadata must fail closed rather than expose legacy/current full reading as if admitted.
 const stripped={...product,surfaceActivation:null};const blocked=renderZiweiProduct({product:stripped});assert.equal(blocked.activationBlocked,true);assert.equal(blocked.fullProductionVisibleToCustomer,false);assert.match(blocked.readingHtml,/data-ziwei-specialist-fail-closed="true"/);assert.doesNotMatch(blocked.readingHtml,/data-ziwei-palace-index/);
}finally{globalThis.fetch=oldFetch;}
if(w17Shared)execFileSync(process.execPath,['scripts/check-ziwei-cx-r1-w17.mjs'],{stdio:'inherit'});
console.log('✓ ZIWEI-CX-R1-W15 admission + W16 Actual Customer Surface Activation passed.');
console.log('  W15: 12/12 human visual & interaction cases ACCEPT by authorized human declaration; machine substitution=false.');
console.log('  W16: current 492ecdd baseline replay 96/96; 1152 palace buttons; 768 topic tabs; 288 timing nodes; activation marker 96/96; interaction 96/96; deterministic replay 8/8.');
console.log('  Full Production is visibly customer-active on /perspectives/personal/ through PPR-R3 + the current Zi Wei specialist renderer; legacy fallback remains fail-closed.');
console.log('  Shared Personal Reality/API/SMR files remain byte-frozen at the current baseline.');

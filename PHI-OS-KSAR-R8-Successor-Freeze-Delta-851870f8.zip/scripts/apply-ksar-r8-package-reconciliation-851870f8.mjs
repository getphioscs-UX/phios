import assert from 'node:assert/strict';
import fs from 'node:fs';
import {execFileSync} from 'node:child_process';

const BASELINE='851870f8abefa9a1c3cdb12e4f2f3265fd70ba27';
const head=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
assert.equal(head,BASELINE,`Expected HEAD ${BASELINE}, got ${head}`);
const p='package.json';
const pkg=JSON.parse(fs.readFileSync(p,'utf8'));
const s=pkg.scripts||{};
const preKnowledge='npm run check:knowledge-runtime && npm run check:ksar && npm run check:kau-r2 && npm run check:ksar-r4-r8 && npm run check:ksar-r1-r8';
const postKnowledge=preKnowledge+' && npm run check:ksar-r8';
assert([preKnowledge,postKnowledge].includes(s['check:knowledge-access']),'Unexpected check:knowledge-access at 851870f8; refusing broad package rewrite.');
const preMain='npm run check:ksar-r1-r8';
if(!s.check.includes('npm run check:ksar-r8')){
  assert(s.check.endsWith(preMain),'Main check no longer ends at check:ksar-r1-r8; refusing unsafe append.');
  s.check+=' && npm run check:ksar-r8';
}
s['ksar:r8:freeze']='node scripts/freeze-ksar-r8-production.mjs';
s['ksar:r8:close']='node scripts/close-ksar-r8-remote-and-freeze.mjs';
s['check:ksar-r8']='node scripts/check-ksar-r8-production-freeze.mjs';
s['check:knowledge-access']=postKnowledge;
fs.writeFileSync(p,JSON.stringify(pkg,null,2)+'\n','utf8');
console.log('✓ package.json reconciled for KSAR-R8 on 851870f8 without replacing current KAU-R5 / Knowledge Runtime scripts.');
console.log('  Added: ksar:r8:freeze, ksar:r8:close, check:ksar-r8.');
console.log('  check and check:knowledge-access now require the final R8 successor freeze.');
